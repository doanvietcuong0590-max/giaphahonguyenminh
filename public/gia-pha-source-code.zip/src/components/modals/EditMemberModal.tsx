import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Save, 
  Trash2, 
  User, 
  Calendar, 
  Heart, 
  MapPin, 
  Phone, 
  Award,
  BookOpen,
  Camera,
  Upload,
  Link,
  Check,
  RotateCcw,
  Image as ImageIcon,
  KeyRound,
  Eye,
  EyeOff,
  RefreshCw,
  ShieldCheck,
  Lock
} from 'lucide-react';
import { Member, Gender, MemberRank } from '../../types';
import { getAvailableGenerations, toRoman, getGenerationTitle } from '../../utils/treeUtils';

interface EditMemberModalProps {
  isOpen: boolean;
  member: Member | null;
  onClose: () => void;
  onUpdateMember: (updatedMember: Member) => void;
  onDeleteMember: (memberId: string) => void;
  members: Member[];
  isAdmin?: boolean;
}

export const EditMemberModal: React.FC<EditMemberModalProps> = ({
  isOpen,
  member,
  onClose,
  onUpdateMember,
  onDeleteMember,
  members,
  isAdmin = true,
}) => {
  if (!isOpen || !member) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fullName, setFullName] = useState(member.fullName);
  const [courtesyName, setCourtesyName] = useState(member.courtesyName || '');
  const [tabooName, setTabooName] = useState(member.tabooName || '');
  const [gender, setGender] = useState<Gender>(member.gender);
  const [generation, setGeneration] = useState<number>(member.generation);
  const [isCustomGen, setIsCustomGen] = useState<boolean>(false);
  const [branch, setBranch] = useState(member.branch);
  const [birthYear, setBirthYear] = useState<number | string>(member.birthYear);
  const [birthDate, setBirthDate] = useState(member.birthDate || '');
  const [isAlive, setIsAlive] = useState(member.isAlive);
  const [deathYear, setDeathYear] = useState<number | string>(member.deathYear || '');
  const [lunarDeathDate, setLunarDeathDate] = useState(member.lunarDeathDate || '');
  const [burialPlace, setBurialPlace] = useState(member.burialPlace || '');
  const [rank, setRank] = useState<MemberRank>(member.rank);
  const [phone, setPhone] = useState(member.phone || '');
  const [password, setPassword] = useState(member.password || '');
  const [showPassword, setShowPassword] = useState(false);
  const [address, setAddress] = useState(member.address || '');
  const [profession, setProfession] = useState(member.profession || '');
  const [bio, setBio] = useState(member.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(member.avatarUrl);

  const [isUploading, setIsUploading] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [customUrl, setCustomUrl] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);

  // Sync state whenever member changes
  useEffect(() => {
    if (member) {
      setFullName(member.fullName);
      setCourtesyName(member.courtesyName || '');
      setTabooName(member.tabooName || '');
      setGender(member.gender);
      setGeneration(member.generation);
      setBranch(member.branch);
      setBirthYear(member.birthYear);
      setBirthDate(member.birthDate || '');
      setIsAlive(member.isAlive);
      setDeathYear(member.deathYear || '');
      setLunarDeathDate(member.lunarDeathDate || '');
      setBurialPlace(member.burialPlace || '');
      setRank(member.rank);
      setPhone(member.phone || '');
      setPassword(member.password || '');
      setShowPassword(false);
      setAddress(member.address || '');
      setProfession(member.profession || '');
      setBio(member.bio || '');
      setAvatarUrl(member.avatarUrl);
      setShowUrlInput(false);
      setCustomUrl('');
    }
  }, [member]);

  const availableGenerations = getAvailableGenerations(members);

  const presetAvatarsMale = [
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=300',
  ];

  const presetAvatarsFemale = [
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1543332164-6e82f355badc?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=300',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=300',
  ];

  const currentPresets = gender === 'female' ? presetAvatarsFemale : presetAvatarsMale;

  // Handle uploading avatar from computer/device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn tệp tin hình ảnh hợp lệ (PNG, JPG, JPEG, WEBP)!');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setAvatarUrl(event.target.result as string);
      }
      setIsUploading(false);
    };
    reader.onerror = () => {
      setIsUploading(false);
      alert('Có lỗi khi đọc tệp ảnh từ máy tính.');
    };
    reader.readAsDataURL(file);

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Drag & drop file
  const handleDropFile = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setIsUploading(true);
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setAvatarUrl(event.target.result as string);
        }
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyCustomUrl = () => {
    if (customUrl.trim()) {
      setAvatarUrl(customUrl.trim());
      setCustomUrl('');
      setShowUrlInput(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) return;

    const finalGen = Math.max(1, Number(generation) || 1);

    onUpdateMember({
      ...member,
      fullName: fullName.trim(),
      courtesyName: courtesyName.trim() || undefined,
      tabooName: tabooName.trim() || undefined,
      gender,
      generation: finalGen,
      branch,
      birthDate: birthDate || undefined,
      birthYear: birthYear || 1990,
      deathDate: !isAlive ? (deathYear ? `${deathYear}` : undefined) : undefined,
      deathYear: !isAlive ? deathYear : undefined,
      lunarDeathDate: !isAlive && lunarDeathDate ? lunarDeathDate : undefined,
      isAlive,
      avatarUrl,
      bio: bio.trim() || undefined,
      burialPlace: !isAlive && burialPlace.trim() ? burialPlace.trim() : undefined,
      rank,
      phone: phone.trim() || undefined,
      password: password.trim() || undefined,
      address: address.trim() || undefined,
      profession: profession.trim() || undefined,
      generationTitle: getGenerationTitle(finalGen),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-amber-950 via-stone-900 to-amber-900 text-amber-50 flex items-center justify-between border-b border-amber-800/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-600/40 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <User className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-sm sm:text-base font-serif text-amber-100">
              Chỉnh Sửa Hồ Sơ Thành Viên
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-stone-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Avatar Selector Section */}
          <div className="p-3.5 rounded-2xl bg-stone-100/80 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>Ảnh đại diện thành viên</span>
              </label>
              <span className="text-[11px] text-stone-500 dark:text-stone-400">
                Đổi ảnh đại diện
              </span>
            </div>

            {/* Avatar Preview & Main Action */}
            <div className="flex items-center gap-4">
              {/* Preview Circle with Drop Area */}
              <div 
                onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDropFile}
                onClick={() => fileInputRef.current?.click()}
                className={`relative group cursor-pointer w-20 h-20 rounded-2xl overflow-hidden border-2 shrink-0 transition-all flex items-center justify-center bg-stone-200 dark:bg-stone-700 ${
                  isDragOver 
                    ? 'border-amber-500 ring-4 ring-amber-400/40 scale-105' 
                    : 'border-amber-600/60 dark:border-amber-500/60 shadow-md'
                }`}
                title="Nhấn để tải ảnh từ máy tính hoặc kéo thả ảnh vào đây"
              >
                {avatarUrl ? (
                  <img 
                    src={avatarUrl} 
                    alt={fullName || "Member Avatar Preview"} 
                    referrerPolicy="no-referrer" 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                  />
                ) : (
                  <ImageIcon className="w-8 h-8 text-stone-400" />
                )}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-semibold gap-0.5">
                  <Upload className="w-4 h-4" />
                  <span>Đổi ảnh</span>
                </div>
                {isUploading && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <span className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
              </div>

              {/* Upload Action Buttons */}
              <div className="flex-1 space-y-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 active:scale-95 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Chọn ảnh từ máy tính</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-750 text-stone-700 dark:text-stone-300 text-xs font-medium flex items-center gap-1 transition-colors"
                  >
                    <Link className="w-3.5 h-3.5 text-stone-500" />
                    <span>{showUrlInput ? 'Đóng link' : 'Chèn link'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-stone-500 dark:text-stone-400 leading-tight">
                  Hỗ trợ định dạng JPG, PNG, WEBP. Kéo & thả trực tiếp vào ô ảnh.
                </p>
              </div>
            </div>

            {/* URL input field if opened */}
            {showUrlInput && (
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="url"
                  placeholder="Dán đường dẫn ảnh trực tuyến (https://...)"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl text-xs text-stone-900 dark:text-stone-100 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="button"
                  onClick={handleApplyCustomUrl}
                  disabled={!customUrl.trim()}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-semibold shrink-0"
                >
                  Áp dụng
                </button>
              </div>
            )}

            {/* Preset Avatars Carousel */}
            <div className="space-y-1 pt-1 border-t border-stone-200/70 dark:border-stone-700/60">
              <span className="text-[11px] font-medium text-stone-500 dark:text-stone-400 block">
                Hoặc chọn ảnh chân dung mẫu:
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scrollbar-none">
                {currentPresets.map((url, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => setAvatarUrl(url)}
                    className={`relative w-10 h-10 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      avatarUrl === url
                        ? 'border-amber-600 ring-2 ring-amber-400 scale-105 shadow-sm'
                        : 'border-stone-200 dark:border-stone-700 opacity-70 hover:opacity-100 hover:scale-102'
                    }`}
                  >
                    <img src={url} alt="Preset avatar" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    {avatarUrl === url && (
                      <div className="absolute inset-0 bg-amber-900/30 flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 text-white drop-shadow" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-700 dark:text-stone-300">
              Họ và tên đầy đủ <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3.5 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs text-stone-900 dark:text-stone-100 focus:outline-none focus:border-amber-500 font-semibold"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-600 dark:text-stone-400">Tên tự (Tên chữ)</label>
              <input
                type="text"
                value={courtesyName}
                onChange={(e) => setCourtesyName(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs text-stone-900 dark:text-stone-100"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-600 dark:text-stone-400">Tên húy</label>
              <input
                type="text"
                value={tabooName}
                onChange={(e) => setTabooName(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs text-stone-900 dark:text-stone-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 dark:text-stone-300">Giới tính</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as Gender)}
                className="w-full px-2.5 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs"
              >
                <option value="male">Nam</option>
                <option value="female">Nữ</option>
              </select>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-stone-700 dark:text-stone-300">Đời thứ</label>
                <button
                  type="button"
                  onClick={() => setIsCustomGen(!isCustomGen)}
                  className="text-[10px] text-amber-700 dark:text-amber-400 hover:underline"
                >
                  {isCustomGen ? 'Danh sách' : 'Tùy chỉnh'}
                </button>
              </div>

              {!isCustomGen ? (
                <select
                  value={generation}
                  onChange={(e) => setGeneration(Number(e.target.value))}
                  className="w-full px-2.5 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs font-semibold"
                >
                  {availableGenerations.map(g => (
                    <option key={g} value={g}>
                      Đời {g} ({toRoman(g)})
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="number"
                  min={1}
                  max={100}
                  placeholder="Số đời..."
                  value={generation}
                  onChange={(e) => setGeneration(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-2.5 py-2 bg-stone-50 dark:bg-stone-800 border border-amber-400 rounded-xl text-xs font-bold"
                />
              )}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-700 dark:text-stone-300">Vai vế</label>
              <select
                value={rank}
                onChange={(e) => setRank(e.target.value as MemberRank)}
                className="w-full px-2.5 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs"
              >
                <option value="truong">Trưởng</option>
                <option value="thu">Thứ</option>
                <option value="dau">Dâu</option>
                <option value="re">Rể</option>
              </select>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-amber-50/70 dark:bg-stone-800/80 border border-amber-200 dark:border-stone-700 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-900 dark:text-stone-100">Tình trạng:</span>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                  <input
                    type="radio"
                    name="editIsAlive"
                    checked={isAlive}
                    onChange={() => setIsAlive(true)}
                    className="text-amber-600"
                  />
                  <span>🟢 Còn sống</span>
                </label>
                <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                  <input
                    type="radio"
                    name="editIsAlive"
                    checked={!isAlive}
                    onChange={() => setIsAlive(false)}
                    className="text-amber-600"
                  />
                  <span>⚪ Đã khuất</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <div>
                <label className="text-[11px] text-stone-600 dark:text-stone-400 block mb-0.5">Năm sinh</label>
                <input
                  type="number"
                  value={birthYear}
                  onChange={(e) => setBirthYear(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg text-xs"
                />
              </div>

              {!isAlive ? (
                <div>
                  <label className="text-[11px] text-stone-600 dark:text-stone-400 block mb-0.5">Năm mất</label>
                  <input
                    type="number"
                    value={deathYear}
                    onChange={(e) => setDeathYear(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg text-xs"
                  />
                </div>
              ) : (
                <div>
                  <label className="text-[11px] text-stone-600 dark:text-stone-400 block mb-0.5">Số điện thoại</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg text-xs"
                  />
                </div>
              )}
            </div>

            {!isAlive && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <div>
                  <label className="text-[11px] text-red-600 dark:text-red-400 font-semibold block mb-0.5">
                    Ngày giỗ âm lịch
                  </label>
                  <input
                    type="text"
                    value={lunarDeathDate}
                    onChange={(e) => setLunarDeathDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white dark:bg-stone-900 border border-red-200 dark:border-red-900/50 rounded-lg text-xs text-red-700 dark:text-red-300 font-medium"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-stone-600 dark:text-stone-400 block mb-0.5">
                    Nơi an táng / Mộ phần
                  </label>
                  <input
                    type="text"
                    value={burialPlace}
                    onChange={(e) => setBurialPlace(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-lg text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Admin Change Password Section */}
          {isAlive && isAdmin && (
            <div className="p-3.5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-amber-950 dark:text-amber-200 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>Admin: Đổi mật khẩu đăng nhập</span>
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300">
                    {member.password ? 'Đã có mật khẩu' : 'Chưa có mật khẩu'}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const rand = Math.floor(1000 + Math.random() * 9000);
                      setPassword(`GiaPha@${rand}`);
                      setShowPassword(true);
                    }}
                    className="text-[11px] text-amber-700 dark:text-amber-300 hover:underline flex items-center gap-1 font-semibold"
                    title="Tạo mật khẩu ngẫu nhiên"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Tạo mới</span>
                  </button>
                </div>
              </div>

              <div className="relative flex items-center">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Nhập mật khẩu mới cho thành viên..."
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pr-10 pl-3 py-2 bg-white dark:bg-stone-800 border border-amber-300/80 dark:border-amber-800/80 rounded-xl text-xs text-stone-900 dark:text-stone-100 focus:outline-none focus:border-amber-500 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
                  title={showPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'}
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>

              <p className="text-[10.5px] text-stone-500 dark:text-stone-400 leading-tight">
                Quản trị viên có thể đổi mật khẩu bất kỳ lúc nào để hỗ trợ thành viên lấy lại tài khoản hoặc cấp quyền truy cập.
              </p>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-stone-700 dark:text-stone-300">
              Tiểu sử & Công đức dòng họ
            </label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs text-stone-900 dark:text-stone-100"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                if (confirm(`Bạn có chắc chắn muốn xóa thành viên "${member.fullName}" khỏi gia phả?`)) {
                  onDeleteMember(member.id);
                  onClose();
                }
              }}
              className="px-3 py-2 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Xóa thành viên</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold shadow-md flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Cập nhật</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
